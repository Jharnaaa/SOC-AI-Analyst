# MITRE ATT&CK Technique Reference (subset used by this SOC)

## T1110 — Brute Force
Adversaries attempt to gain access to accounts by systematically guessing passwords.
Sub-technique T1110.001 (Password Guessing) covers repeated login attempts against a
single account. Common mitigation: account lockout thresholds, MFA, IP reputation
filtering at the perimeter.

## T1595 — Active Scanning
Adversaries scan victim infrastructure to gather information for targeting, often
performed from the same infrastructure used in an initial brute-force attempt once a
foothold or reconnaissance opportunity is identified.

## T1486 — Data Encrypted for Impact
Adversaries encrypt data on target systems to disrupt availability, typically as the
final stage of a ransomware operation. Frequently preceded by data exfiltration
(double-extortion) and preceded further upstream by an initial-access technique
exploiting an unpatched vulnerability or phishing.

## T1041 — Exfiltration Over C2 Channel
Data is stolen over the same channel used for command-and-control communication, often
immediately before a destructive action such as encryption, maximizing leverage in
extortion.

## T1055 — Process Injection
Adversaries inject code into legitimate processes to evade detection and elevate
privileges — commonly observed as part of ransomware loaders masquerading as system
processes (e.g., a renamed svchost variant).

## T1078 — Valid Accounts
Adversaries use compromised legitimate credentials to bypass access controls, most
relevant when a brute-force or credential-stuffing attempt is followed by a successful
login.
