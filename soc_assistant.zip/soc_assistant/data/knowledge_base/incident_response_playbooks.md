# Incident Response Playbooks

## IR-PLAYBOOK-BRUTEFORCE — Credential Brute Force / Stuffing
Trigger: 5+ failed logins for one account within 15 minutes, or failed logins across
many accounts from one source IP.
Steps:
1. Pull identity provider events for the account and source IP over the last 24h.
2. Check threat intelligence reputation of the source IP.
3. Check SIEM for related events (scanning, subsequent successful logins from the same
   or nearby IPs).
4. If source IP is malicious AND no successful login occurred: severity = Medium,
   contain by blocking the IP at the firewall, keep account lockout in place, notify
   the user through a verified channel.
5. If source IP is malicious AND a successful login occurred afterward: severity =
   High/Critical, treat as suspected account compromise, force password reset, require
   human approval before any account disablement.
6. Document root cause, timeline, and confidence in the investigation report.

## IR-PLAYBOOK-RANSOMWARE — Ransomware / Mass Encryption
Trigger: EDR reports mass file-modification/encryption behavior, or a ransom note
artifact is observed.
Steps:
1. Immediately pull EDR alert details (host, process, file hash) and SIEM events for the
   affected host in the preceding 6 hours.
2. Check firewall logs for anomalous outbound transfer preceding the encryption event —
   ransomware operations frequently exfiltrate data before encrypting (double extortion).
3. Check threat intelligence for the file hash and any destination IPs involved.
4. Check vulnerability scan results for the host to identify the likely initial-access
   vector (unpatched CVEs).
5. Severity is Critical by default for confirmed mass encryption.
6. Recommended remediation: isolate host from network, preserve forensic image, rotate
   credentials used on that host, block malicious IPs/hashes across the estate, patch
   the identified initial-access CVE fleet-wide.
7. Human approval is required before disabling any user account tied to the incident.

## IR-PLAYBOOK-SUSPICIOUS-LOGIN — Suspicious / Anomalous Login
Trigger: login from unrecognized geography/device, or MFA challenge failure pattern.
Steps:
1. Pull identity events for the account (recent logins, geos, devices).
2. Cross-reference source IP against threat intelligence.
3. Check whether MFA is enrolled for the account (unenrolled = higher risk).
4. If risk indicators are present, recommend forced re-authentication and MFA
   enrollment; do not disable the account without human approval.

## IR-PLAYBOOK-MALICIOUS-IP — IP Reputation Investigation
Trigger: Analyst or user asks whether a specific IP is malicious.
Steps:
1. Query threat intelligence for the IOC.
2. Pull firewall logs and SIEM events referencing that IP internally, if any.
3. Report reputation, confidence, associated threat actor/tags, and any observed
   internal activity involving that IP.
