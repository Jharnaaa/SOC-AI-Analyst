# Security Policies

## Account Lockout Policy (POL-IAM-004)
Accounts are automatically locked after 5 consecutive failed login attempts within a
15-minute window. Lockouts persist for 30 minutes or until an administrator or the
identity provider's self-service unlock flow clears them. Any lockout triggered from a
source IP with a known-malicious threat intelligence reputation must be escalated to
Tier 2 as a suspected credential-stuffing or brute-force event rather than treated as a
routine user error.

## Multi-Factor Authentication Policy (POL-IAM-011)
All privileged and remote-access accounts must be enrolled in MFA. Accounts without MFA
enrollment that show authentication activity from new devices or geographies are treated
as elevated risk and require manual review before any password reset is approved.

## Acceptable Outbound Traffic Policy (POL-NET-002)
Outbound connections exceeding 500MB to a destination not on the corporate CDN/SaaS
allow-list must generate a SIEM alert. Any outbound transfer immediately followed by
mass file-modification activity on the same host is treated as a potential
exfiltration-then-encryption ransomware pattern under IR-PLAYBOOK-RANSOMWARE.

## Data Classification & Handling Policy (POL-DATA-001)
Confidential and Restricted data must not traverse unencrypted channels or leave
approved egress points. Any EDR or DLP alert involving Restricted data must be treated
as at least High severity regardless of other contextual signals.

## User Account Disablement Policy (POL-IAM-020)
Disabling a user account is a high-impact, hard-to-reverse action. It requires either
(a) explicit human analyst/manager approval logged in the ticketing system, or (b) a
Critical-severity confirmed compromise with active lateral movement, in which case an
analyst may act first and obtain retroactive approval within 1 hour. The assistant must
never disable an account autonomously without one of these two conditions being met and
recorded.
