# SOC Runbooks (operational, tool-level)

## RB-01 Investigating an Account Lockout
1. Identity API: fetch the user's recent identity_events (failures, lockout, geo,
   source IP).
2. If failures came from an external IP, run Threat Intel API lookup on that IP.
3. SIEM API: search for correlated events involving the same account or IP in the same
   time window (e.g., subsequent recon or successful login).
4. Cross-check EDR for any endpoint alerts tied to the account's usual device.
5. Determine root cause: user error vs. brute force vs. credential stuffing vs.
   confirmed compromise.
6. Assign severity per IR-PLAYBOOK-BRUTEFORCE and cite it in the report.

## RB-02 Investigating a Malware / Ransomware Alert
1. EDR API: pull the alert (host, process, hash, technique, status).
2. SIEM API: pull events for the host across a 6-hour window before/after the alert.
3. Firewall API: check for outbound transfers preceding the alert.
4. Threat Intel API: check reputation of file hash and any external IPs contacted.
5. Vulnerability Scanner API: check the host for unpatched CVEs that explain initial
   access.
6. Assemble timeline in chronological order across all sources, cite IR-PLAYBOOK-RANSOMWARE.

## RB-03 IP Reputation Check
1. Threat Intel API: direct IOC lookup.
2. Firewall + SIEM API: check for any internal traffic to/from the IP.
3. Report reputation, confidence, and any local exposure.

## RB-04 Failed Logins Report (Today)
1. Identity API: pull all login_failure and lockout events for the current day.
2. Group by account and by source IP.
3. Flag any source IP with a malicious threat-intel reputation.

## General Tool Selection Heuristic
- Question mentions a user/account -> Identity API first.
- Question mentions an IP -> Threat Intel API first, then Firewall/SIEM for local
  context.
- Question mentions malware/ransomware/an alert -> EDR API first, then SIEM, Firewall,
  Threat Intel, Vulnerability Scanner in that order.
- Always close by checking the Knowledge Base for the matching playbook before writing
  the final report, so severity and recommended actions are policy-grounded rather than
  improvised.
