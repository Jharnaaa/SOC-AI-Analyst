# Compliance Guidelines

## Breach Notification Timelines
Confirmed incidents involving unauthorized access to customer or employee personal data
must be escalated to the Privacy/Legal team within 4 hours of confirmation so that
regulatory notification windows (e.g., 72-hour GDPR, state breach-notification laws) can
be met. The assistant should flag any investigation where personal data exposure is
plausible so a human can make the escalation call — the assistant does not itself
determine legal reportability.

## Audit Logging Requirement
Every investigation performed by the SOC assistant — tools invoked, data retrieved, and
conclusions reached — must be logged with timestamps for audit purposes. This supports
both internal review and external audit/compliance requests (SOC 2, ISO 27001).

## Least-Privilege for Automated Actions
Automated or AI-assisted tooling may query and read security telemetry broadly, but
write/administrative actions (disabling accounts, quarantining hosts, blocking IPs at
the firewall) require a human-in-the-loop approval step, consistent with
POL-IAM-020. This is a compliance control, not just an operational preference.

## Evidence Preservation
When an investigation identifies a likely confirmed incident (not a false positive),
relevant logs and endpoint forensic artifacts must be preserved before any remediation
that could alter or destroy evidence (e.g., reimaging a host) is carried out.
