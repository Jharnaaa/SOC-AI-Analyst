"""
build_db.py
Creates and seeds mock_security.db — the mock 'enterprise security stack' database
backing the SOC AI Analyst. Represents 6 systems as tables:

  identity_events   -> Identity Provider (Okta/Azure AD style)
  users             -> Identity Provider user directory
  siem_events       -> SIEM (Splunk/Sentinel style correlated events)
  firewall_logs     -> Perimeter firewall / NGFW logs
  edr_alerts        -> Endpoint Detection & Response (CrowdStrike/Defender style)
  threat_intel      -> Threat Intelligence feed (IOCs)
  vuln_scans        -> Vulnerability scanner (Nessus/Qualys style) results

Run: python3 build_db.py
"""
import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "mock_security.db")

SCHEMA = """
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS identity_events;
DROP TABLE IF EXISTS siem_events;
DROP TABLE IF EXISTS firewall_logs;
DROP TABLE IF EXISTS edr_alerts;
DROP TABLE IF EXISTS threat_intel;
DROP TABLE IF EXISTS vuln_scans;

CREATE TABLE users (
    username TEXT PRIMARY KEY,
    full_name TEXT,
    department TEXT,
    status TEXT,               -- active | locked | disabled
    last_login TEXT,
    mfa_enrolled INTEGER
);

CREATE TABLE identity_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    username TEXT,
    event_type TEXT,           -- login_success | login_failure | lockout | mfa_challenge | password_reset
    source_ip TEXT,
    geo TEXT,
    reason TEXT
);

CREATE TABLE siem_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    event_id TEXT,
    severity TEXT,              -- low | medium | high | critical
    category TEXT,               -- authentication | malware | exfiltration | ransomware | recon
    username TEXT,
    source_ip TEXT,
    dest_ip TEXT,
    description TEXT,
    mitre_technique TEXT
);

CREATE TABLE firewall_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    source_ip TEXT,
    dest_ip TEXT,
    dest_port INTEGER,
    protocol TEXT,
    action TEXT,                -- allow | block
    bytes_out INTEGER,
    rule_name TEXT
);

CREATE TABLE edr_alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    hostname TEXT,
    username TEXT,
    alert_type TEXT,
    process_name TEXT,
    file_hash TEXT,
    severity TEXT,
    mitre_technique TEXT,
    status TEXT                 -- new | investigating | contained | resolved
);

CREATE TABLE threat_intel (
    ioc_value TEXT PRIMARY KEY,
    ioc_type TEXT,               -- ip | hash | domain
    reputation TEXT,              -- malicious | suspicious | clean
    threat_actor TEXT,
    confidence INTEGER,
    first_seen TEXT,
    tags TEXT
);

CREATE TABLE vuln_scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hostname TEXT,
    cve_id TEXT,
    severity TEXT,
    cvss_score REAL,
    description TEXT,
    patch_available INTEGER,
    scan_date TEXT
);
"""

def now_minus(minutes):
    return (datetime.utcnow() - timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%SZ")

def seed(conn):
    cur = conn.cursor()

    # --- users ---
    cur.executemany(
        "INSERT INTO users VALUES (?,?,?,?,?,?)",
        [
            ("jsmith", "John Smith", "Finance", "locked", now_minus(40), 1),
            ("agarcia", "Ana Garcia", "Engineering", "active", now_minus(120), 1),
            ("rkhan", "Raj Khan", "IT", "active", now_minus(15), 0),
            ("mchen", "Mei Chen", "HR", "active", now_minus(600), 1),
        ],
    )

    # --- identity_events (John Smith lockout scenario) ---
    events = []
    base = 55
    for i in range(6):
        events.append((now_minus(base - i * 3), "jsmith", "login_failure", "185.220.101.7",
                        "Bucharest, RO", "invalid_password"))
    events.append((now_minus(40), "jsmith", "lockout", "185.220.101.7", "Bucharest, RO",
                    "5_failed_attempts_exceeded_threshold"))
    events.append((now_minus(10), "jsmith", "login_success", "10.0.4.22", "Chicago, US", None))
    events.append((now_minus(90), "agarcia", "login_success", "10.0.2.15", "Austin, US", None))
    events.append((now_minus(20), "rkhan", "mfa_challenge", "10.0.9.4", "Austin, US", "device_not_recognized"))
    cur.executemany(
        "INSERT INTO identity_events (timestamp, username, event_type, source_ip, geo, reason) VALUES (?,?,?,?,?,?)",
        events,
    )

    # --- siem_events (correlated: brute force -> lockout, plus ransomware alert) ---
    siem = [
        (now_minus(56), "EVT-10231", "medium", "authentication", "jsmith", "185.220.101.7", "10.0.4.22",
         "Multiple failed authentication attempts against VPN gateway", "T1110 - Brute Force"),
        (now_minus(40), "EVT-10238", "high", "authentication", "jsmith", "185.220.101.7", "10.0.4.22",
         "Account lockout triggered after threshold exceeded", "T1110.001 - Password Guessing"),
        (now_minus(38), "EVT-10240", "high", "recon", None, "185.220.101.7", "10.0.0.0/16",
         "Source IP fingerprinted scanning internal subnet ranges post-lockout", "T1595 - Active Scanning"),
        (now_minus(180), "EVT-10199", "critical", "ransomware", "rkhan", "10.0.9.4", "10.0.9.4",
         "Mass file encryption behavior detected on host FIN-WKS-014, ransom note dropped (readme_recover.txt)",
         "T1486 - Data Encrypted for Impact"),
        (now_minus(175), "EVT-10201", "critical", "exfiltration", "rkhan", "10.0.9.4", "45.83.120.19",
         "Large outbound transfer (1.2GB) to unrecognized external host preceding encryption event",
         "T1041 - Exfiltration Over C2 Channel"),
    ]
    cur.executemany(
        "INSERT INTO siem_events (timestamp,event_id,severity,category,username,source_ip,dest_ip,description,mitre_technique) VALUES (?,?,?,?,?,?,?,?,?)",
        siem,
    )

    # --- firewall_logs ---
    fw = [
        (now_minus(56), "185.220.101.7", "10.0.4.22", 443, "TCP", "allow", 4200, "ALLOW-VPN-INBOUND"),
        (now_minus(38), "185.220.101.7", "10.0.0.5", 22, "TCP", "block", 0, "BLOCK-SSH-EXTERNAL"),
        (now_minus(176), "10.0.9.4", "45.83.120.19", 8443, "TCP", "allow", 1258000000, "ALLOW-HTTPS-OUTBOUND"),
        (now_minus(174), "10.0.9.4", "45.83.120.19", 8443, "TCP", "block", 0, "BLOCK-C2-KNOWN-BAD (added post-incident)"),
    ]
    cur.executemany(
        "INSERT INTO firewall_logs (timestamp,source_ip,dest_ip,dest_port,protocol,action,bytes_out,rule_name) VALUES (?,?,?,?,?,?,?,?)",
        fw,
    )

    # --- edr_alerts ---
    edr = [
        (now_minus(178), "FIN-WKS-014", "rkhan", "ransomware_behavior", "svchost_updater.exe",
         "a1b2c3d4e5f67890a1b2c3d4e5f67890", "critical", "T1486 - Data Encrypted for Impact", "investigating"),
        (now_minus(179), "FIN-WKS-014", "rkhan", "suspicious_process_injection", "svchost_updater.exe",
         "a1b2c3d4e5f67890a1b2c3d4e5f67890", "high", "T1055 - Process Injection", "investigating"),
        (now_minus(9), "CORP-LAP-101", "jsmith", "benign_login", None, None, "low", None, "resolved"),
    ]
    cur.executemany(
        "INSERT INTO edr_alerts (timestamp,hostname,username,alert_type,process_name,file_hash,severity,mitre_technique,status) VALUES (?,?,?,?,?,?,?,?,?)",
        edr,
    )

    # --- threat_intel ---
    ti = [
        ("185.220.101.7", "ip", "malicious", "Unknown (Tor exit node)", 85, "2025-11-02",
         "tor-exit,credential-stuffing,brute-force"),
        ("45.83.120.19", "ip", "malicious", "FIN-RANSOM-12 (suspected affiliate)", 92, "2026-01-15",
         "c2,ransomware,exfiltration"),
        ("a1b2c3d4e5f67890a1b2c3d4e5f67890", "hash", "malicious", "FIN-RANSOM-12", 95, "2026-01-10",
         "ransomware,loader"),
        ("10.0.2.15", "ip", "clean", None, 0, None, "internal-corporate"),
    ]
    cur.executemany(
        "INSERT INTO threat_intel (ioc_value,ioc_type,reputation,threat_actor,confidence,first_seen,tags) VALUES (?,?,?,?,?,?,?)",
        ti,
    )

    # --- vuln_scans ---
    vs = [
        ("FIN-WKS-014", "CVE-2024-21412", "high", 8.1,
         "Windows SmartScreen security feature bypass allowing initial-access malware to run unprompted", 1,
         now_minus(60 * 24 * 5)),
        ("FIN-WKS-014", "CVE-2023-23397", "critical", 9.8,
         "Outlook privilege escalation vulnerability exploitable without user interaction", 1,
         now_minus(60 * 24 * 5)),
        ("CORP-LAP-101", "CVE-2025-1097", "medium", 5.4,
         "Local information disclosure in outdated VPN client", 1, now_minus(60 * 24 * 2)),
    ]
    cur.executemany(
        "INSERT INTO vuln_scans (hostname,cve_id,severity,cvss_score,description,patch_available,scan_date) VALUES (?,?,?,?,?,?,?)",
        vs,
    )

    conn.commit()


def main():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    seed(conn)
    conn.close()
    print(f"Built {DB_PATH}")


if __name__ == "__main__":
    main()
