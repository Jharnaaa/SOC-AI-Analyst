"""
rag.py
Lightweight RAG layer over the SOC knowledge base (policies, playbooks, MITRE ATT&CK,
runbooks, compliance guidelines). Chunks each markdown file by its '##' sections and
retrieves the most relevant chunks for a query with TF-IDF cosine similarity — no
external embedding API required, so this works fully offline. Swap `retrieve()`'s
internals for a real vector DB (pgvector/Chroma/Pinecone) + embeddings model in
production without changing the calling code in agent.py.
"""
import os
import re
import glob
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

KB_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base")


class KnowledgeBase:
    def __init__(self, kb_dir: str = KB_DIR):
        self.chunks = []       # list of {"source": filename, "heading": str, "text": str}
        self._load(kb_dir)
        self._vectorizer = TfidfVectorizer(stop_words="english")
        self._matrix = self._vectorizer.fit_transform([c["text"] for c in self.chunks])

    def _load(self, kb_dir):
        for path in sorted(glob.glob(os.path.join(kb_dir, "*.md"))):
            fname = os.path.basename(path)
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            # split on '## ' headings, keep the heading with its body
            sections = re.split(r"\n(?=## )", content)
            for sec in sections:
                sec = sec.strip()
                if not sec or sec.startswith("# "):
                    # top-level title-only chunk, or empty — skip pure titles
                    if sec.startswith("## "):
                        pass
                    else:
                        continue
                heading_match = re.match(r"##\s+(.*)", sec)
                heading = heading_match.group(1) if heading_match else fname
                self.chunks.append({"source": fname, "heading": heading, "text": sec})

    def retrieve(self, query: str, k: int = 3):
        q_vec = self._vectorizer.transform([query])
        sims = cosine_similarity(q_vec, self._matrix).flatten()
        top_idx = sims.argsort()[::-1][:k]
        results = []
        for i in top_idx:
            if sims[i] <= 0:
                continue
            c = self.chunks[i]
            results.append({
                "source": c["source"],
                "heading": c["heading"],
                "text": c["text"],
                "score": round(float(sims[i]), 4),
            })
        return results


if __name__ == "__main__":
    kb = KnowledgeBase()
    for r in kb.retrieve("account lockout brute force"):
        print(r["source"], "-", r["heading"], "(score", r["score"], ")")
