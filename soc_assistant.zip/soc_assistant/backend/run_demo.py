"""
run_demo.py
Zero-dependency (beyond scikit-learn) CLI demo of the agent pipeline, useful for
verifying the install before standing up the FastAPI server. Runs the 5 example
questions from the project spec through the full plan -> execute -> ground -> report
pipeline and prints each investigation report.
"""
from agent import SOCAgent, format_report_text

EXAMPLE_QUESTIONS = [
    "Why was user John locked out?",
    "Investigate suspicious login attempts for rkhan",
    "Is IP 45.83.120.19 malicious?",
    "Show failed logins today.",
    "Explain yesterday's ransomware alert on FIN-WKS-014",
]


def main():
    agent = SOCAgent()
    for q in EXAMPLE_QUESTIONS:
        print("=" * 90)
        report = agent.ask(q)
        print(format_report_text(report))
        print()

    print("=" * 90)
    print(f"Session history length: {len(agent.history)} turns (context is maintained across turns)")


if __name__ == "__main__":
    main()
