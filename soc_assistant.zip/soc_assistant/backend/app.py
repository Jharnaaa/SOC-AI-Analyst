"""
app.py
FastAPI wrapper exposing the SOC AI Analyst as a conversational API.

Run:
    pip install -r requirements.txt
    uvicorn app:app --reload --port 8000

Endpoints:
    POST /chat            {"session_id": "abc", "message": "Why was user John locked out?"}
                           -> full structured investigation report (JSON) + a text summary
    GET  /sessions/{id}    -> conversation history for a session
    GET  /health           -> liveness check
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import uuid

from agent import SOCAgent, format_report_text

app = FastAPI(
    title="Enterprise Security Incident Investigator",
    description="Agentic SOC AI Analyst combining threat intel, SIEM, EDR, identity, "
                "and playbooks (RAG) to investigate security incidents.",
    version="1.0.0",
)

# In-memory session store: {session_id: SOCAgent}. Swap for Redis/DB for multi-instance
# deployments.
SESSIONS: dict[str, SOCAgent] = {}


class ChatRequest(BaseModel):
    session_id: Optional[str] = None
    message: str


class ChatResponse(BaseModel):
    session_id: str
    summary: str
    report: dict


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())
    agent = SESSIONS.setdefault(session_id, SOCAgent())
    report = agent.ask(req.message)
    return ChatResponse(
        session_id=session_id,
        summary=format_report_text(report),
        report=report,
    )


@app.get("/sessions/{session_id}")
def get_session(session_id: str):
    agent = SESSIONS.get(session_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Unknown session_id")
    return {"session_id": session_id, "history": agent.history}
