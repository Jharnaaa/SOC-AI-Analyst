"""
mock_apis.py
Mock security product APIs. In a real deployment each function body would be
replaced with an HTTP call to the real product (Splunk/Sentinel, Okta/Azure AD,
Palo Alto/Fortinet, CrowdStrike/Defender, a TI feed like VirusTotal/Recorded Future,
Qualys/Nessus). The function signatures and return shapes are what the agent plans
and reasons over, so they're written to look like a real integration layer.
"""
import sqlite3
import os
from typing import Optional

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "db", "mock_security.db")


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _rows(cur):
    return [dict(r) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# 1. Identity Provider API
# ---------------------------------------------------------------------------
class IdentityAPI:
    name = "Identity Provider API"

    @staticmethod
    def get_user(username: str) -> Optional[dict]:
        conn = _conn()
        row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()
        return dict(row) if row else None

    @staticmethod
    def get_user_events(username: str, limit: int = 25) -> list:
        conn = _conn()
        cur = conn.execute(
            "SELECT * FROM identity_events WHERE username = ? ORDER BY timestamp DESC LIMIT ?",
            (username, limit),
        )
        rows = _rows(cur)
        conn.close()
        return rows

    @staticmethod
    def get_failed_logins_today() -> list:
        conn = _conn()
        cur = conn.execute(
            "SELECT * FROM identity_events WHERE event_type IN ('login_failure','lockout') "
            "ORDER BY timestamp DESC"
        )
        rows = _rows(cur)
        conn.close()
        return rows


# ---------------------------------------------------------------------------
# 2. SIEM API
# ---------------------------------------------------------------------------
class SIEMAPi:
    name = "SIEM API"

    @staticmethod
    def query_events(username: str = None, source_ip: str = None, hostname: str = None,
                      category: str = None, limit: int = 50) -> list:
        conn = _conn()
        clauses, params = [], []
        if username:
            clauses.append("username = ?"); params.append(username)
        if source_ip:
            clauses.append("(source_ip = ? OR dest_ip = ?)"); params += [source_ip, source_ip]
        if category:
            clauses.append("category = ?"); params.append(category)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        cur = conn.execute(f"SELECT * FROM siem_events {where} ORDER BY timestamp DESC LIMIT ?",
                            params + [limit])
        rows = _rows(cur)
        conn.close()
        return rows


# ---------------------------------------------------------------------------
# 3. Firewall API
# ---------------------------------------------------------------------------
class FirewallAPI:
    name = "Firewall API"

    @staticmethod
    def get_logs(ip: str = None, limit: int = 50) -> list:
        conn = _conn()
        if ip:
            cur = conn.execute(
                "SELECT * FROM firewall_logs WHERE source_ip = ? OR dest_ip = ? "
                "ORDER BY timestamp DESC LIMIT ?", (ip, ip, limit))
        else:
            cur = conn.execute("SELECT * FROM firewall_logs ORDER BY timestamp DESC LIMIT ?", (limit,))
        rows = _rows(cur)
        conn.close()
        return rows


# ---------------------------------------------------------------------------
# 4. Endpoint Detection & Response (EDR) API
# ---------------------------------------------------------------------------
class EDRAPi:
    name = "EDR API"

    @staticmethod
    def get_alerts(hostname: str = None, username: str = None, limit: int = 50) -> list:
        conn = _conn()
        clauses, params = [], []
        if hostname:
            clauses.append("hostname = ?"); params.append(hostname)
        if username:
            clauses.append("username = ?"); params.append(username)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        cur = conn.execute(f"SELECT * FROM edr_alerts {where} ORDER BY timestamp DESC LIMIT ?",
                            params + [limit])
        rows = _rows(cur)
        conn.close()
        return rows


# ---------------------------------------------------------------------------
# 5. Threat Intelligence API
# ---------------------------------------------------------------------------
class ThreatIntelAPI:
    name = "Threat Intelligence API"

    @staticmethod
    def check_ioc(value: str) -> dict:
        conn = _conn()
        row = conn.execute("SELECT * FROM threat_intel WHERE ioc_value = ?", (value,)).fetchone()
        conn.close()
        if row:
            return dict(row)
        return {"ioc_value": value, "reputation": "unknown", "confidence": 0,
                "note": "No intelligence on record for this indicator."}


# ---------------------------------------------------------------------------
# 6. Vulnerability Scanner API
# ---------------------------------------------------------------------------
class VulnScannerAPI:
    name = "Vulnerability Scanner API"

    @staticmethod
    def get_vulns(hostname: str) -> list:
        conn = _conn()
        cur = conn.execute(
            "SELECT * FROM vuln_scans WHERE hostname = ? ORDER BY cvss_score DESC", (hostname,))
        rows = _rows(cur)
        conn.close()
        return rows


TOOL_REGISTRY = {
    "identity_get_user_events": (IdentityAPI.get_user_events, IdentityAPI.name),
    "identity_get_failed_logins_today": (IdentityAPI.get_failed_logins_today, IdentityAPI.name),
    "identity_get_user": (IdentityAPI.get_user, IdentityAPI.name),
    "siem_query_events": (SIEMAPi.query_events, SIEMAPi.name),
    "firewall_get_logs": (FirewallAPI.get_logs, FirewallAPI.name),
    "edr_get_alerts": (EDRAPi.get_alerts, EDRAPi.name),
    "threat_intel_check_ioc": (ThreatIntelAPI.check_ioc, ThreatIntelAPI.name),
    "vuln_get_vulns": (VulnScannerAPI.get_vulns, VulnScannerAPI.name),
}
