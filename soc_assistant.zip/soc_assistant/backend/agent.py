"""
agent.py
The agentic core of the SOC AI Analyst.

Pipeline for every user turn:
  1. PLAN    — extract entities (username / IP / hostname) from the question and decide
               which mock security tools to call and in what order (mirrors the
               Identity -> SIEM -> Threat Intel -> Playbook flow in the spec).
  2. EXECUTE — call those tools against the mock database, collecting raw evidence.
  3. GROUND  — retrieve the matching policy/playbook/runbook chunks from the RAG
               knowledge base so severity & recommended actions are policy-grounded.
  4. REPORT  — synthesize an explainable Investigation Report: Timeline, Root Cause,
               Severity, Tools Used, Confidence Score, Recommended Remediation, and
               whether human approval is required for any suggested action.

This reference implementation plans with transparent, auditable rules (see
plan_conversational() in mock_apis-tool-selection style) rather than an opaque black
box — every planning decision is inspectable. To upgrade this into an LLM-driven planner
(recommended for production), replace `Planner.plan()` with a call to the Claude API
using tool_use / function calling, passing TOOL_REGISTRY's schemas as `tools` — the
EXECUTE/GROUND/REPORT stages don't need to change. See README.md for the wiring.
"""
import re
from datetime import datetime
from mock_apis import (
    IdentityAPI, SIEMAPi, FirewallAPI, EDRAPi, ThreatIntelAPI, VulnScannerAPI,
)
from rag import KnowledgeBase

IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
HOST_RE = re.compile(r"\b[A-Z]{2,}-[A-Z0-9]+-\d+\b", re.IGNORECASE)


class Planner:
    """Rule-based intent + entity extraction -> ordered tool-call plan."""

    def plan(self, question: str):
        q = question.lower()
        entities = self._extract_entities(question)
        steps = []

        if "today" in q and any(w in q for w in ["failed login", "failed logins", "login failure"]) and not entities["username"]:
            intent = "failed_logins_today"
            steps.append(("identity_get_failed_logins_today", {}))
            steps.append(("kb_lookup", {"query": "failed logins report daily"}))

        elif any(w in q for w in ["locked out", "lockout", "login failure", "failed login", "can't log in", "cannot log in"]):
            intent = "account_lockout"
            steps.append(("identity_get_user_events", {"username": entities["username"]}))
            if entities["username"]:
                steps.append(("identity_get_user", {"username": entities["username"]}))
            steps.append(("siem_query_events", {"username": entities["username"]}))
            steps.append(("threat_intel_lookup_from_events", {}))  # resolved after identity events
            steps.append(("kb_lookup", {"query": "account lockout brute force policy"}))

        elif any(w in q for w in ["ransomware", "encrypted", "encryption", "malware alert"]):
            intent = "ransomware_investigation"
            steps.append(("edr_get_alerts", {"hostname": entities["hostname"]}))
            steps.append(("siem_query_events", {"hostname": entities["hostname"]}))
            steps.append(("firewall_get_logs", {"ip": entities["ip"]}))
            steps.append(("threat_intel_lookup_from_events", {}))
            steps.append(("vuln_get_vulns", {"hostname": entities["hostname"]}))
            steps.append(("kb_lookup", {"query": "ransomware playbook exfiltration"}))

        elif any(w in q for w in ["malicious", "reputation", "is this ip"]) and entities["ip"]:
            intent = "ip_reputation"
            steps.append(("threat_intel_check_ioc", {"value": entities["ip"]}))
            steps.append(("firewall_get_logs", {"ip": entities["ip"]}))
            steps.append(("siem_query_events", {"source_ip": entities["ip"]}))
            steps.append(("kb_lookup", {"query": "malicious ip investigation threat intelligence"}))

        elif any(w in q for w in ["suspicious login", "suspicious logins", "anomalous login"]):
            intent = "suspicious_login"
            steps.append(("identity_get_user_events", {"username": entities["username"]}))
            steps.append(("threat_intel_lookup_from_events", {}))
            steps.append(("kb_lookup", {"query": "suspicious anomalous login MFA"}))

        else:
            intent = "general"
            if entities["username"]:
                steps.append(("identity_get_user_events", {"username": entities["username"]}))
            if entities["ip"]:
                steps.append(("threat_intel_check_ioc", {"value": entities["ip"]}))
            if entities["hostname"]:
                steps.append(("edr_get_alerts", {"hostname": entities["hostname"]}))
            steps.append(("kb_lookup", {"query": question}))

        return {"intent": intent, "entities": entities, "steps": steps}

    def _extract_entities(self, question: str):
        ip_match = IP_RE.search(question)
        host_match = HOST_RE.search(question)
        username = None
        ql = question.lower()
        for name in ["jsmith", "agarcia", "rkhan", "mchen"]:
            if name in ql:
                username = name
        if not username:
            for first, mapped in [("john", "jsmith"), ("ana", "agarcia"),
                                   ("raj", "rkhan"), ("mei", "mchen")]:
                if first in ql:
                    username = mapped
        return {
            "username": username,
            "ip": ip_match.group(0) if ip_match else None,
            "hostname": host_match.group(0).upper() if host_match else None,
        }


class Executor:
    """Runs the planned tool calls against the mock APIs, recording provenance."""

    def __init__(self):
        self.kb = KnowledgeBase()

    def execute(self, plan: dict):
        evidence = []   # list of {"tool": name, "params": {...}, "result": ...}
        entities = plan["entities"]

        for step_name, params in plan["steps"]:
            if step_name == "identity_get_user_events" and params.get("username"):
                res = IdentityAPI.get_user_events(params["username"])
                evidence.append({"tool": "Identity Provider API", "call": step_name,
                                  "params": params, "result": res})

            elif step_name == "identity_get_user" and params.get("username"):
                res = IdentityAPI.get_user(params["username"])
                evidence.append({"tool": "Identity Provider API", "call": step_name,
                                  "params": params, "result": res})

            elif step_name == "identity_get_failed_logins_today":
                res = IdentityAPI.get_failed_logins_today()
                evidence.append({"tool": "Identity Provider API", "call": step_name,
                                  "params": params, "result": res})

            elif step_name == "siem_query_events":
                clean = {k: v for k, v in params.items() if v}
                res = SIEMAPi.query_events(**clean)
                evidence.append({"tool": "SIEM API", "call": step_name,
                                  "params": clean, "result": res})

            elif step_name == "firewall_get_logs":
                clean = {k: v for k, v in params.items() if v}
                res = FirewallAPI.get_logs(**clean)
                evidence.append({"tool": "Firewall API", "call": step_name,
                                  "params": clean, "result": res})

            elif step_name == "edr_get_alerts":
                clean = {k: v for k, v in params.items() if v}
                res = EDRAPi.get_alerts(**clean)
                evidence.append({"tool": "EDR API", "call": step_name,
                                  "params": clean, "result": res})

            elif step_name == "vuln_get_vulns" and params.get("hostname"):
                res = VulnScannerAPI.get_vulns(params["hostname"])
                evidence.append({"tool": "Vulnerability Scanner API", "call": step_name,
                                  "params": params, "result": res})

            elif step_name == "threat_intel_check_ioc" and params.get("value"):
                res = ThreatIntelAPI.check_ioc(params["value"])
                evidence.append({"tool": "Threat Intelligence API", "call": step_name,
                                  "params": params, "result": res})

            elif step_name == "threat_intel_lookup_from_events":
                # Dynamically pivot: look up TI for every distinct external IP / hash
                # surfaced by identity/SIEM/EDR evidence gathered so far.
                ips = set()
                for ev in evidence:
                    for row in (ev["result"] if isinstance(ev["result"], list) else []):
                        for field in ("source_ip", "dest_ip"):
                            if isinstance(row, dict) and row.get(field):
                                ips.add(row[field])
                        if isinstance(row, dict) and row.get("file_hash"):
                            ips.add(row["file_hash"])
                if entities.get("ip"):
                    ips.add(entities["ip"])
                results = {ip: ThreatIntelAPI.check_ioc(ip) for ip in ips}
                evidence.append({"tool": "Threat Intelligence API", "call": step_name,
                                  "params": {"iocs": list(ips)}, "result": results})

            elif step_name == "kb_lookup":
                res = self.kb.retrieve(params["query"], k=3)
                evidence.append({"tool": "Knowledge Base (RAG)", "call": step_name,
                                  "params": params, "result": res})

        return evidence


class ReportSynthesizer:
    """Turns raw evidence into an explainable Investigation Report."""

    def synthesize(self, question: str, plan: dict, evidence: list):
        intent = plan["intent"]
        timeline = self._build_timeline(evidence)
        malicious_iocs = self._malicious_iocs(evidence)
        root_cause, severity, confidence, remediation, human_approval = self._assess(
            intent, evidence, malicious_iocs
        )
        kb_citations = [e["result"] for e in evidence if e["call"] == "kb_lookup"]
        kb_citations = kb_citations[0] if kb_citations else []

        tools_used = sorted({e["tool"] for e in evidence})

        report = {
            "question": question,
            "intent": intent,
            "timeline": timeline,
            "root_cause": root_cause,
            "severity": severity,
            "confidence_score": confidence,
            "tools_used": tools_used,
            "knowledge_base_citations": [
                f"{c['source']} — {c['heading']}" for c in kb_citations
            ],
            "recommended_remediation": remediation,
            "requires_human_approval": human_approval,
            "raw_evidence": evidence,
            "generated_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        return report

    def _build_timeline(self, evidence):
        events = []
        for e in evidence:
            res = e["result"]
            rows = res if isinstance(res, list) else []
            for row in rows:
                if isinstance(row, dict) and row.get("timestamp"):
                    label = (row.get("description") or row.get("event_type") or
                              row.get("alert_type") or row.get("rule_name") or e["tool"])
                    events.append({"timestamp": row["timestamp"], "source": e["tool"],
                                    "detail": label})
        events.sort(key=lambda x: x["timestamp"])
        return events

    def _malicious_iocs(self, evidence):
        bad = []
        for e in evidence:
            res = e["result"]
            if e["call"] == "threat_intel_check_ioc" and isinstance(res, dict):
                if res.get("reputation") == "malicious":
                    bad.append(res)
            if e["call"] == "threat_intel_lookup_from_events" and isinstance(res, dict):
                for ioc, data in res.items():
                    if data.get("reputation") == "malicious":
                        bad.append(data)
        return bad

    def _assess(self, intent, evidence, malicious_iocs):
        """Rule-based severity/root-cause assessment grounded in the mock evidence.
        In production this synthesis step is the natural place to hand the collected
        evidence + KB citations to an LLM (Claude) to write the narrative — the
        structured fields below would become the prompt's grounding context."""
        human_approval = True  # default posture per POL-IAM-020 / compliance guidelines

        if intent == "account_lockout":
            successful_after = any(
                isinstance(row, dict) and row.get("event_type") == "login_success"
                for e in evidence if e["call"] == "identity_get_user_events"
                for row in (e["result"] or [])
            )
            if malicious_iocs and successful_after:
                return ("Account lockout preceded by a credential brute-force attempt "
                        "from a known-malicious IP, followed by a successful login — "
                        "suspected account compromise.",
                        "Critical", 0.88,
                        ["Force immediate password reset", "Revoke active sessions",
                         "Require human approval before disabling the account",
                         "Notify user via a verified out-of-band channel"],
                        True)
            elif malicious_iocs:
                return ("Account lockout caused by repeated failed logins from a "
                        "known-malicious IP (brute force / credential stuffing). No "
                        "successful login observed afterward.",
                        "Medium", 0.82,
                        ["Block source IP at the firewall", "Keep account locked pending user verification",
                         "Notify user via a verified out-of-band channel"],
                        False)
            else:
                return ("Account lockout appears consistent with routine repeated "
                        "failed login attempts (e.g. forgotten password); no malicious "
                        "indicators found on the source IP.",
                        "Low", 0.7,
                        ["Verify identity and perform standard self-service unlock"],
                        False)

        if intent == "ransomware_investigation":
            has_exfil = any(
                isinstance(row, dict) and row.get("category") == "exfiltration"
                for e in evidence if e["call"] == "siem_query_events"
                for row in (e["result"] or [])
            )
            vulns = []
            for e in evidence:
                if e["call"] == "vuln_get_vulns":
                    vulns = e["result"] or []
            top_cve = vulns[0]["cve_id"] if vulns else None
            root_cause = ("Confirmed ransomware: mass file-encryption behavior detected on the "
                          "endpoint" + (", preceded by outbound data exfiltration to a known-malicious "
                          "C2 IP (double-extortion pattern)" if has_exfil else "") +
                          (f". Likely initial access via unpatched {top_cve}." if top_cve else "."))
            return (root_cause, "Critical", 0.9,
                    ["Isolate affected host from the network immediately",
                     "Preserve forensic disk/memory image before remediation",
                     "Rotate all credentials used on the affected host",
                     "Block malicious IPs/hashes across the environment",
                     f"Patch {top_cve} fleet-wide" if top_cve else "Patch identified vulnerabilities fleet-wide",
                     "Human approval required before disabling any associated user account"],
                    True)

        if intent == "ip_reputation":
            ti = next((e["result"] for e in evidence if e["call"] == "threat_intel_check_ioc"), {})
            rep = ti.get("reputation", "unknown")
            conf = (ti.get("confidence", 0) or 0) / 100
            has_internal_activity = any(
                e["result"] for e in evidence if e["call"] in ("firewall_get_logs", "siem_query_events")
            )
            if rep == "malicious":
                return (f"IP is flagged malicious by threat intelligence"
                        f"{' (' + ti.get('threat_actor') + ')' if ti.get('threat_actor') else ''}"
                        f"{'; internal traffic to/from this IP was observed' if has_internal_activity else '; no internal traffic to/from this IP was found'}.",
                        "High" if has_internal_activity else "Medium",
                        max(conf, 0.6),
                        ["Block IP at the firewall if not already blocked",
                         "Review any internal hosts that communicated with this IP"],
                        False)
            elif rep == "clean":
                return ("IP has a clean reputation with no malicious associations on record.",
                        "Low", 0.75, ["No action required"], False)
            else:
                return ("No threat intelligence on record for this IP; reputation is unknown.",
                        "Low", 0.4, ["Monitor for further activity; consider enrichment from an external feed"],
                        False)

        if intent == "failed_logins_today":
            rows = next((e["result"] for e in evidence if e["call"] == "identity_get_failed_logins_today"), [])
            flagged_users = sorted({r["username"] for r in rows if r.get("event_type") in ("login_failure", "lockout")})
            return (f"{len(rows)} failed-login/lockout events recorded today across "
                    f"{len(flagged_users)} account(s): {', '.join(flagged_users) if flagged_users else 'none'}.",
                    "Medium" if malicious_iocs else "Low",
                    0.8, ["Review flagged accounts for brute-force patterns",
                          "Cross-check source IPs against threat intelligence"],
                    False)

        if intent == "suspicious_login":
            return ("Login activity reviewed for anomalous device/geography and MFA status.",
                    "Medium" if malicious_iocs else "Low", 0.65,
                    ["Require MFA re-enrollment/re-authentication if risk indicators are present"],
                    False)

        return ("Insufficient signal to determine a specific root cause from the available "
                "mock data sources for this question.", "Low", 0.3,
                ["Clarify the account, IP, or host under investigation"], False)


class SOCAgent:
    """Top-level conversational agent: maintains simple per-session context and runs
    the plan -> execute -> ground -> report pipeline for each user turn."""

    def __init__(self):
        self.planner = Planner()
        self.executor = Executor()
        self.reporter = ReportSynthesizer()
        self.history = []  # list of {"question": ..., "report": ...}

    def ask(self, question: str) -> dict:
        plan = self.planner.plan(question)
        evidence = self.executor.execute(plan)
        report = self.reporter.synthesize(question, plan, evidence)
        self.history.append({"question": question, "report": report})
        return report


def format_report_text(report: dict) -> str:
    lines = []
    lines.append(f"INVESTIGATION REPORT — {report['intent'].replace('_', ' ').title()}")
    lines.append(f"Question: {report['question']}")
    lines.append("")
    lines.append("Timeline:")
    if report["timeline"]:
        for ev in report["timeline"]:
            lines.append(f"  [{ev['timestamp']}] ({ev['source']}) {ev['detail']}")
    else:
        lines.append("  (no time-stamped events found)")
    lines.append("")
    lines.append(f"Root Cause: {report['root_cause']}")
    lines.append(f"Severity: {report['severity']}")
    lines.append(f"Confidence Score: {report['confidence_score']}")
    lines.append(f"Tools Used: {', '.join(report['tools_used'])}")
    if report["knowledge_base_citations"]:
        lines.append(f"Policy/Playbook Basis: {', '.join(report['knowledge_base_citations'])}")
    lines.append("Recommended Remediation:")
    for step in report["recommended_remediation"]:
        lines.append(f"  - {step}")
    lines.append(f"Requires Human Approval for Remediation: {'Yes' if report['requires_human_approval'] else 'No'}")
    return "\n".join(lines)
